<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #dcedfa; /* Light blue base */
            background-image: radial-gradient(circle at 50% 0%, #ffffff 0%, transparent 60%), 
                              radial-gradient(circle at 0% 50%, #ffffff 0%, transparent 50%);
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden; /* Prevent scrolling from background rings */
        }

        /* Card and Inputs */
        .login-card {
            background: white;
            border-radius: 20px;
            padding: 48px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.08);
            z-index: 10;
        }

        .input-wrapper {
            position: relative;
            margin-bottom: 24px;
        }

        .input-email {
            width: 100%;
            padding: 16px 18px;
            border: 1px solid #7cb1df; /* Light blue border */
            border-radius: 8px;
            outline: none;
            font-size: 15px;
            color: #333;
            background: transparent;
        }
        
        .input-email:focus {
            border-color: #1d71b8;
            border-width: 2px;
            padding: 15px 17px; /* Adjust padding to prevent jumping when border gets thicker */
        }

        .label-email {
            position: absolute;
            top: -9px;
            left: 14px;
            background: white;
            padding: 0 6px;
            font-size: 13px;
            color: #7cb1df;
            font-weight: 500;
        }

        .input-password {
            width: 100%;
            padding: 16px 18px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            outline: none;
            font-size: 15px;
            color: #333;
        }
        
        .input-password::placeholder {
            color: #9ca3af;
        }

        .input-password:focus {
            border-color: #9ca3af;
        }

        .btn-signin {
            background-color: #1d71b8;
            color: white;
            padding: 14px;
            border-radius: 8px;
            font-weight: 500;
            font-size: 15px;
            width: 100%;
            transition: all 0.2s;
        }
        
        .btn-signin:hover {
            background-color: #155a96;
        }

        .btn-google {
            background-color: white;
            border: 1px solid #e5e7eb;
            color: #000;
            padding: 14px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.2s;
        }
        
        .btn-google:hover {
            background-color: #f9fafb;
        }

        .custom-checkbox {
            appearance: none;
            -webkit-appearance: none;
            width: 18px;
            height: 18px;
            border: 2px solid #333;
            border-radius: 4px;
            background-color: white;
            display: inline-block;
            position: relative;
            cursor: pointer;
            margin-right: 10px;
        }
        
        .custom-checkbox:checked {
            background-color: #333;
        }
        
        .custom-checkbox:checked::after {
            content: '';
            position: absolute;
            left: 5px;
            top: 2px;
            width: 5px;
            height: 10px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
    </style>
</head>
<body class="flex flex-col">

    <div class="relative z-10 w-full max-w-[500px] px-4 flex flex-col items-center">
        <!-- Logo -->
        <h1 class="text-[26px] font-bold text-[#8ba2b8] tracking-widest mb-8">LOGO</h1>

        <!-- Card -->
        <div class="login-card">
            <!-- Header -->
            <div class="text-center mb-8">
                <h2 class="text-[32px] font-bold text-black tracking-tight mb-3">Sign in</h2>
                <p class="text-[15px] text-gray-500">Please login to continue to your account.</p>
            </div>

            <!-- Form -->
            <form action="#" method="POST">
                
                <!-- Email -->
                <div class="input-wrapper">
                    <label class="label-email">Email</label>
                    <input type="text" class="input-email" required>
                    <!-- Small blinking cursor line effect to match screenshot exactly if needed, but standard input is fine -->
                </div>

                <!-- Password -->
                <div class="input-wrapper">
                    <input type="password" placeholder="Password" class="input-password" required>
                    <!-- Eye slash icon -->
                    <div class="absolute right-4 top-[14px] cursor-pointer text-gray-400 hover:text-gray-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                            <line x1="1" y1="1" x2="23" y2="23"></line>
                        </svg>
                    </div>
                </div>

                <!-- Checkbox -->
                <div class="flex items-center mb-6 mt-2">
                    <input type="checkbox" id="keep" class="custom-checkbox">
                    <label for="keep" class="text-[13px] font-semibold text-black cursor-pointer select-none">Keep me logged in</label>
                </div>

                <!-- Sign In Button -->
                <button type="submit" class="btn-signin">Sign in</button>

                <!-- Divider -->
                <div class="flex items-center my-5">
                    <div class="flex-grow border-t border-gray-100"></div>
                    <span class="mx-4 text-[11px] text-gray-400 font-medium">or</span>
                    <div class="flex-grow border-t border-gray-100"></div>
                </div>

                <!-- Google Button -->
                <button type="button" class="btn-google">
                    Sign in with Google
                    <svg width="18" height="18" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                </button>
            </form>

            <!-- Footer Link -->
            <div class="mt-6 text-center">
                <p class="text-[13px] text-gray-500">
                    Need an account? <a href="#" class="font-medium text-[#7cb1df] hover:underline">Create one</a>
                </p>
            </div>

        </div>
    </div>

</body>
</html>
