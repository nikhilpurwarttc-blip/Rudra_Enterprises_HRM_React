<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\RoleController;
use App\Http\Controllers\Api\PermissionController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\PlantController;
use App\Http\Controllers\Api\ShiftController;
use App\Http\Controllers\Api\HolidayController;
use App\Http\Controllers\Api\ChargeController;
use App\Http\Controllers\Api\DepartmentController;
use App\Http\Controllers\Api\DesignationController;
use App\Http\Controllers\Api\EmployeeController;
use App\Http\Controllers\Api\EmployeeDocumentController;
use App\Http\Controllers\Api\EmployeeBankAccountController;
use App\Http\Controllers\Api\EmployeeAdvanceController;
use App\Http\Controllers\Api\AttendanceController;
use App\Http\Controllers\Api\PlantShutdownController;


Route::middleware(['web', 'throttle:5,1'])->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
});

Route::middleware(['auth:sanctum', 'throttle:120,1'])->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);

    // Current user (both paths for compatibility)
    Route::get('/user', [AuthController::class, 'me']);
    Route::get('/me',   [AuthController::class, 'me']);

    Route::middleware('permission')->group(function () {
        // Seed all standard permissions (idempotent)
        Route::post('/permissions/seed', [PermissionController::class, 'seed']);

        Route::apiResource('roles',       RoleController::class);
        Route::apiResource('permissions', PermissionController::class);
        Route::apiResource('users',       UserController::class);
        Route::apiResource('plants', PlantController::class);
        Route::apiResource('shifts', ShiftController::class);
        Route::apiResource('holidays', HolidayController::class);
        Route::apiResource('charges', ChargeController::class);
        Route::apiResource('departments', DepartmentController::class);
        Route::apiResource('designations', DesignationController::class);
        Route::apiResource('employees', EmployeeController::class);
        Route::apiResource('employee-documents',EmployeeDocumentController::class);
        Route::apiResource('employee-bank-accounts',EmployeeBankAccountController::class);
        Route::apiResource('employee-advances', EmployeeAdvanceController::class);
        Route::post('employee-advances/{employee_advance}/recover', [EmployeeAdvanceController::class, 'recover']);
        Route::post('employee-advances/{employee_advance}/cancel', [EmployeeAdvanceController::class, 'cancel']);
        Route::get('employees/{employee}/advances', [EmployeeAdvanceController::class, 'employeeAdvances']);
        
        // Attendance Routes
        Route::apiResource('attendances', AttendanceController::class);
        Route::get('attendances/pending-verification', [AttendanceController::class, 'pendingVerification']);
        Route::post('attendances/{attendance}/verify', [AttendanceController::class, 'verify']);
        Route::post('attendances/{attendance}/reject', [AttendanceController::class, 'reject']);
        
        // Plant Shutdown Routes
        Route::apiResource('plant-shutdowns', PlantShutdownController::class);
        Route::post('plant-shutdowns/{plant_shutdown}/approve', [PlantShutdownController::class, 'approve']);
        Route::post('plant-shutdowns/{plant_shutdown}/reject', [PlantShutdownController::class, 'reject']);
    });
});
