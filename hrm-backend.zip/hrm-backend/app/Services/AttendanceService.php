<?php

namespace App\Services;

use Carbon\Carbon;
use App\Models\Shift;
use App\Models\Employee;
use App\Models\Attendance;
use App\Models\PlantShutdown;

class AttendanceService
{
    /**
     * Calculate worked hours and determine regular/overtime, taking into account Plant Shutdowns.
     */
    public function calculateHours(string $checkIn, string $checkOut, Shift $shift, int $plantId, string $date): array
    {
        $in = Carbon::parse($checkIn);
        $out = Carbon::parse($checkOut);
        
        $actualWorkedMinutes = $in->diffInMinutes($out);
        $actualWorkedHours = $actualWorkedMinutes / 60;
        
        $regularHours = 0;
        $overtimeHours = 0;
        $lateMinutes = 0;

        // Calculate Late Minutes (if shift start_time is available)
        if ($shift->start_time) {
            // Assume start_time is in H:i:s format. We compare with checkIn time.
            $shiftStart = Carbon::parse($in->format('Y-m-d') . ' ' . $shift->start_time);
            
            // If employee checked in after shift start
            if ($in->greaterThan($shiftStart)) {
                $diff = $shiftStart->diffInMinutes($in);
                // Apply the 5-minute allowance rule
                if ($diff > Attendance::CHECKIN_ALLOWANCE_MINUTES) {
                    $lateMinutes = (int) $diff;
                }
            }
        }
        
        $shiftDuration = $shift->duration_hours ?? 12; // default to 12 as per SRS

        if ($actualWorkedHours <= $shiftDuration) {
            $regularHours = $actualWorkedHours;
            $overtimeHours = 0;
        } else {
            $regularHours = $shiftDuration;
            $overtimeHours = $actualWorkedHours - $shiftDuration;
        }

        // Check if there is an approved plant shutdown during this time
        $shutdown = PlantShutdown::where('plant_id', $plantId)
            ->where('shutdown_date', $date)
            ->where('status', PlantShutdown::STATUS_APPROVED)
            ->first();

        if ($shutdown) {
            // Shutdown Called In:
            // "Plant shutdown is approved. Employee is called in and actually works.
            // Payable hours must be based on actual worked hours.
            // Do not automatically give guaranteed 8 hours when actual work is recorded."
            // This is naturally handled by the logic above, which gives actual worked hours.
        }
        
        return [
            'actual' => round($actualWorkedHours, 2),
            'regular' => round($regularHours, 2),
            'overtime' => round($overtimeHours, 2),
            'late_minutes' => $lateMinutes
        ];
    }

    /**
     * Calculate compensation for a shutdown where the employee is Idle.
     */
    public function calculateShutdownIdleHours(int $employeeId, int $plantId, string $date)
    {
        // "Shutdown Idle: Plant shutdown is approved. Employee is eligible. NOT called in."
        $shutdown = PlantShutdown::where('plant_id', $plantId)
            ->where('shutdown_date', $date)
            ->where('status', PlantShutdown::STATUS_APPROVED)
            ->first();

        if (!$shutdown) {
            return 0; // No approved shutdown
        }

        // Check if the employee was called in (has attendance)
        $hasAttendance = Attendance::where('employee_id', $employeeId)
            ->where('attendance_date', $date)
            ->exists();

        if ($hasAttendance) {
            return 0; // Already handled by actual worked hours
        }

        // Idle, return guaranteed hours
        return $shutdown->guaranteed_hours;
    }
}
