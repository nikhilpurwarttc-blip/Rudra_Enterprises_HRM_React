<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EmployeeResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'employee_code' => $this->employee_code,
            'name' => $this->name,
            'dob' => $this->dob,
            'joining_date' => $this->joining_date,
            'plant_id' => $this->plant_id,
            'plant' => $this->whenLoaded('plant'),
            'department_id' => $this->department_id,
            'department' => $this->whenLoaded('department'),
            'designation_id' => $this->designation_id,
            'designation' => $this->whenLoaded('designation'),
            'status' => $this->status,
            'mobile_number' => $this->mobile_number,
            'email' => $this->email,
            'address' => $this->address,
            'gender' => $this->gender,
            'marital_status' => $this->marital_status,
            'shift_id' => $this->shift_id,
            'shift' => $this->whenLoaded('shift'),
            'image' => $this->image ? asset('storage/' . $this->image) : null,
            'charges' => ChargeResource::collection($this->whenLoaded('charges')),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
