<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Http\Request;

class RoleResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'          => $this->id,
            'name'        => $this->name,
            'description' => $this->description,
            'status'      => (bool) $this->status,
            'users_count' => $this->users_count ?? 0,
            'permissions' => $this->relationLoaded('permissions')
                ? PermissionResource::collection($this->permissions)
                : [],
            'plant_ids'   => $this->relationLoaded('plants')
                ? $this->plants->pluck('id')->values()
                : [],
            'plants'      => $this->whenLoaded('plants'),
            'created_at'  => $this->created_at,
            'updated_at'  => $this->updated_at,
        ];
    }
}
