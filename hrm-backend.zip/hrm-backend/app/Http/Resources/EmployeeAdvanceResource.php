<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\EmployeeAdvance;

class EmployeeAdvanceResource extends JsonResource
{
    public function toArray($request)
    {
        $paymentModeName = $this->payment_mode === EmployeeAdvance::PAYMENT_CASH ? 'Cash' : 'Bank';
        
        $statusName = 'Unknown';
        if ($this->status === EmployeeAdvance::STATUS_PENDING) {
            $statusName = 'Pending';
        } elseif ($this->status === EmployeeAdvance::STATUS_RECOVERED) {
            $statusName = 'Recovered';
        } elseif ($this->status === EmployeeAdvance::STATUS_CANCELLED) {
            $statusName = 'Cancelled';
        }

        return [
            'id' => $this->id,
            'employee_id' => $this->employee_id,
            'advance_date' => $this->advance_date ? $this->advance_date->toDateString() : null,
            'amount' => number_format($this->amount, 2, '.', ''),
            'payment_mode' => $this->payment_mode,
            'payment_mode_name' => $paymentModeName,
            'purpose' => $this->purpose,
            'recovered_amount' => number_format($this->recovered_amount, 2, '.', ''),
            'remaining_amount' => number_format($this->remaining_amount, 2, '.', ''),
            'status' => $this->status,
            'status_name' => $statusName,
            'remarks' => $this->remarks,
            'settlement_date' => $this->settlement_date ? $this->settlement_date->toDateString() : null,
            'employee' => new EmployeeResource($this->whenLoaded('employee')),
        ];
    }
}
