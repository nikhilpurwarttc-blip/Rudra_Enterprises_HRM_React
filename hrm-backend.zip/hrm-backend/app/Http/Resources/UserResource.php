<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        // Build { module: [action, ...] } map from role permissions
        $permissionsMap = (object) []; // empty object, not null
        if ($this->relationLoaded('role') && $this->role?->relationLoaded('permissions')) {
            $map = [];
            foreach ($this->role->permissions as $permission) {
                $map[$permission->module][] = $permission->action;
            }
            $permissionsMap = $map;
        }

        return [
            'id'          => $this->id,
            'name'        => $this->name,
            'username'    => $this->username,
            'email'       => $this->email,
            'status'      => (bool) $this->status,
            'role_id'     => $this->role_id,
            'employee_id' => $this->employee_id,
            'role'        => $this->whenLoaded('role', fn() => [
                'id'          => $this->role->id,
                'name'        => $this->role->name,
                'description' => $this->role->description,
                'plant_ids'   => $this->role->relationLoaded('plants')
                    ? $this->role->plants->pluck('id')->values()
                    : [],
            ]),
            'employee'    => new EmployeeResource($this->whenLoaded('employee')),
            'permissions' => $permissionsMap,
            'created_at'  => $this->created_at,
        ];
    }
}
