<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Http\Requests\StoreDepartmentRequest;
use App\Http\Requests\UpdateDepartmentRequest;
use App\Http\Resources\DepartmentResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DepartmentController extends Controller
{
    public function index(Request $request)
    {
        $query = Department::query();
        
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null) {
            $query->whereHas('plants', fn ($plants) => $plants->whereIn('plants.id', $allowedPlantIds));
        }
        
        if ($request->filled('plant_id')) {
            $query->where('plant_id', $request->plant_id);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where('name', 'like', "%{$search}%");
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        $departments = $query->with('plants')->orderBy('name')->orderBy('id')->paginate($perPage);
        return DepartmentResource::collection($departments);
    }

    public function store(StoreDepartmentRequest $request)
    {
        $data = $request->validated();
        $plantIds = $data['plant_id'];
        if ($request->user()->accessiblePlantIds() !== null && array_diff($plantIds, $request->user()->accessiblePlantIds())) {
            return response()->json(['message' => 'You do not have access to one or more selected plants.'], 403);
        }
        $data['plant_id'] = $plantIds[0];
        
        if (Auth::check()) {
            $data['created_by'] = Auth::id();
        }

        $department = Department::create($data);
        $department->plants()->sync($plantIds);
        return new DepartmentResource($department->load('plants'));
    }

    public function show(Request $request, Department $department)
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && !$department->plants()->whereIn('plants.id', $allowedPlantIds)->exists()) {
            return response()->json(['message' => 'You do not have access to this department.'], 403);
        }
        return new DepartmentResource($department);
    }

    public function update(UpdateDepartmentRequest $request, Department $department)
    {
        $data = $request->validated();
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && !$department->plants()->whereIn('plants.id', $allowedPlantIds)->exists()) {
            return response()->json(['message' => 'You do not have access to this department.'], 403);
        }
        if (array_key_exists('plant_id', $data)) {
            $plantIds = $data['plant_id'];
            if ($allowedPlantIds !== null && array_diff($plantIds, $allowedPlantIds)) {
                return response()->json(['message' => 'You do not have access to one or more selected plants.'], 403);
            }
            $data['plant_id'] = $plantIds[0];
        }
        $department->update($data);
        if (isset($plantIds)) $department->plants()->sync($plantIds);
        return new DepartmentResource($department->load('plants'));
    }

    public function destroy(Request $request, Department $department)
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && !$department->plants()->whereIn('plants.id', $allowedPlantIds)->exists()) {
            return response()->json(['message' => 'You do not have access to this department.'], 403);
        }
        $department->delete();
        return response()->json(['message' => 'Department deleted successfully']);
    }
}
