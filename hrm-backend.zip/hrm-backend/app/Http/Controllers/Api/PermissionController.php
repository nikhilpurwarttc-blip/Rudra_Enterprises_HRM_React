<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Http\Requests\StorePermissionRequest;
use App\Http\Requests\UpdatePermissionRequest;
use App\Http\Resources\PermissionResource;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        $query = Permission::query();
        
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('module', 'like', "%{$search}%")
                  ->orWhere('action', 'like', "%{$search}%");
            });
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        // Ensure backward compatibility for pages that don't pass pagination parameters
        if ($request->has('all') && $request->all === 'true' || !$request->has('page')) {
            return PermissionResource::collection($query->orderBy('module')->orderBy('action')->get());
        }

        return PermissionResource::collection($query->orderBy('module')->orderBy('action')->orderBy('id')->paginate($perPage));
    }

    public function store(StorePermissionRequest $request)
    {
        $permission = Permission::create($request->validated());
        return new PermissionResource($permission);
    }

    public function show(Permission $permission)
    {
        return new PermissionResource($permission);
    }

    public function update(UpdatePermissionRequest $request, Permission $permission)
    {
        $permission->update($request->validated());
        return new PermissionResource($permission);
    }

    public function destroy(Permission $permission)
    {
        $permission->delete();
        return response()->json(['message' => 'Permission deleted successfully']);
    }

    /**
     * POST /permissions/seed
     * Bulk-create all standard HRM permissions from the matrix.
     * Skips existing (module + action) combinations.
     */
    public function seed(Request $request)
    {
        $validated = $request->validate([
            'modules' => 'sometimes|array',
            'modules.*' => 'required|string|max:100',
        ]);
        $defaultModules = [
            'dashboard', 'plants', 'departments', 'designations', 'shifts', 'festivals', 'charges',
            'employees', 'employee-view', 'attendance', 'advances', 'attendance-report',
            'salary-report', 'maintenance-report', 'roles', 'users',
        ];
        $modules = array_values(array_unique($validated['modules'] ?? $defaultModules));
        $actions = ['view', 'create', 'edit', 'delete'];

        $created = 0;
        foreach ($modules as $module) {
            foreach ($actions as $action) {
                $name = $module . '.' . $action;
                $exists = Permission::where('module', $module)->where('action', $action)->exists();
                if (!$exists) {
                    Permission::create(['name' => $name, 'module' => $module, 'action' => $action]);
                    $created++;
                }
            }
        }

        return response()->json([
            'message' => "Seeded {$created} permission(s). Existing ones were skipped.",
            'created' => $created,
        ]);
    }
}
