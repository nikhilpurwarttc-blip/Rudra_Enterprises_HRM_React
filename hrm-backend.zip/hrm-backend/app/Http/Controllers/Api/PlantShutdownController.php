<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\PlantShutdown;
use Illuminate\Http\Request;
use App\Http\Requests\StorePlantShutdownRequest;
use App\Http\Requests\UpdatePlantShutdownRequest;
use Illuminate\Support\Facades\DB;

class PlantShutdownController extends Controller
{
    public function index(Request $request)
    {
        $query = PlantShutdown::with(['plant', 'approvedBy']);

        if ($request->has('plant_id')) {
            $query->where('plant_id', $request->plant_id);
        }

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        if ($request->has('start_date')) {
            $query->where('shutdown_date', '>=', $request->start_date);
        }

        if ($request->has('end_date')) {
            $query->where('shutdown_date', '<=', $request->end_date);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        return response()->json($query->orderBy('shutdown_date', 'desc')->paginate($perPage));
    }

    public function store(StorePlantShutdownRequest $request)
    {
        $data = $request->validated();

        $data['status'] = PlantShutdown::STATUS_PENDING;
        // Configurable default guaranteed hours (SRS default is 8)
        $data['guaranteed_hours'] = config('attendance.shutdown_guaranteed_hours', 8.0);

        DB::beginTransaction();
        try {
            $shutdown = PlantShutdown::create($data);
            DB::commit();
            return response()->json($shutdown->load('plant'), 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Failed to create shutdown'], 500);
        }
    }

    public function show(PlantShutdown $plantShutdown)
    {
        return response()->json($plantShutdown->load(['plant', 'approvedBy']));
    }

    public function update(UpdatePlantShutdownRequest $request, PlantShutdown $plantShutdown)
    {
        if ($plantShutdown->status !== PlantShutdown::STATUS_PENDING) {
            return response()->json(['message' => 'Only pending shutdowns can be updated.'], 422);
        }

        $data = $request->validated();

        DB::beginTransaction();
        try {
            $plantShutdown->update($data);
            DB::commit();
            return response()->json($plantShutdown->load('plant'));
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Failed to update shutdown'], 500);
        }
    }

    public function destroy(PlantShutdown $plantShutdown)
    {
        if ($plantShutdown->status === PlantShutdown::STATUS_APPROVED) {
            return response()->json(['message' => 'Cannot delete an approved shutdown. It may be referenced in payroll.'], 422);
        }

        $plantShutdown->delete();
        return response()->json(['message' => 'Shutdown deleted successfully.']);
    }

    public function approve(Request $request, PlantShutdown $plantShutdown)
    {
        if ($plantShutdown->status !== PlantShutdown::STATUS_PENDING) {
            return response()->json(['message' => 'Only pending shutdowns can be approved.'], 422);
        }

        DB::beginTransaction();
        try {
            $plantShutdown->update([
                'status' => PlantShutdown::STATUS_APPROVED,
                'approved_by' => $request->user()->id,
                'approved_at' => now(),
            ]);
            DB::commit();
            return response()->json(['message' => 'Shutdown approved successfully.', 'data' => $plantShutdown]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Failed to approve shutdown'], 500);
        }
    }

    public function reject(Request $request, PlantShutdown $plantShutdown)
    {
        if ($plantShutdown->status !== PlantShutdown::STATUS_PENDING) {
            return response()->json(['message' => 'Only pending shutdowns can be rejected.'], 422);
        }

        $request->validate([
            'remarks' => 'required|string',
        ]);

        DB::beginTransaction();
        try {
            $plantShutdown->update([
                'status' => PlantShutdown::STATUS_REJECTED,
                'remarks' => $request->remarks,
            ]);
            DB::commit();
            return response()->json(['message' => 'Shutdown rejected successfully.', 'data' => $plantShutdown]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Failed to reject shutdown'], 500);
        }
    }
}
