<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreChargeRequest;
use App\Http\Requests\UpdateChargeRequest;
use App\Http\Resources\ChargeResource;
use App\Models\Charge;
use Illuminate\Http\Request;

class ChargeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Charge::query();
        
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where('name', 'like', "%{$search}%");
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        return ChargeResource::collection($query->orderBy('name')->orderBy('id')->paginate($perPage));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreChargeRequest $request)
    {
        $charge = Charge::create($request->validated());
        return new ChargeResource($charge);
    }

    /**
     * Display the specified resource.
     */
    public function show(Charge $charge)
    {
        return new ChargeResource($charge);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateChargeRequest $request, Charge $charge)
    {
        $charge->update($request->validated());
        return new ChargeResource($charge);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Charge $charge)
    {
        $charge->delete();
        return response()->json(['message' => 'Charge deleted successfully']);
    }
}
