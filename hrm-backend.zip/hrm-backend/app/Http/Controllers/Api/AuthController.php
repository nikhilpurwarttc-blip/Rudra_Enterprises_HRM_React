<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\LoginRequest;
use App\Http\Resources\UserResource;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(LoginRequest $request)
    {
        if (!Auth::attempt($request->only('username', 'password'))) {
            return response()->json(['message' => 'Invalid login credentials'], 401);
        }

        $user = Auth::user();

        if (!$user->status) {
            Auth::logout();
            return response()->json(['message' => 'Your account is disabled.'], 403);
        }

        $request->session()->regenerate();

        return response()->json([
            'user'         => new UserResource($user->load('role.permissions', 'role.plants', 'employee')),
        ]);
    }

    public function me(Request $request)
    {
        // Always fresh — load role with permissions
        $user = $request->user()->load('role.permissions', 'role.plants', 'employee');
        return new UserResource($user);
    }

    public function logout(Request $request)
    {
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return response()->json(['message' => 'Successfully logged out']);
    }
}
