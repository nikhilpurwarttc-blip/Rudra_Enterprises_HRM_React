<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\EmployeeAdvance;
use App\Models\Employee;
use App\Http\Requests\StoreEmployeeAdvanceRequest;
use App\Http\Requests\UpdateEmployeeAdvanceRequest;
use App\Http\Requests\RecoverEmployeeAdvanceRequest;
use App\Http\Resources\EmployeeAdvanceResource;
use Illuminate\Http\Request;

class EmployeeAdvanceController extends Controller
{
    public function index(Request $request)
    {
        $query = EmployeeAdvance::with(['employee', 'createdBy']);

        if ($request->filled('employee_id')) {
            $query->where('employee_id', $request->employee_id);
        }

        if ($request->filled('payment_mode')) {
            $query->where('payment_mode', $request->payment_mode);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        if ($request->filled('start_date')) {
            $query->where('advance_date', '>=', $request->start_date);
        }

        if ($request->filled('end_date')) {
            $query->where('advance_date', '<=', $request->end_date);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        $advances = $query->latest('advance_date')->orderBy('id', 'desc')->paginate($perPage);

        return EmployeeAdvanceResource::collection($advances);
    }

    public function store(StoreEmployeeAdvanceRequest $request)
    {
        $data = $request->validated();
        $data['recovered_amount'] = 0;
        $data['status'] = EmployeeAdvance::STATUS_PENDING;
        $data['created_by'] = $request->user()->id ?? null;
        $data['settlement_date'] = \Carbon\Carbon::parse($data['advance_date'])->endOfMonth()->toDateString();
        
        $advance = EmployeeAdvance::create($data);
        return new EmployeeAdvanceResource($advance->load(['employee', 'createdBy']));
    }

    public function show(EmployeeAdvance $employeeAdvance)
    {
        return new EmployeeAdvanceResource($employeeAdvance->load(['employee', 'createdBy']));
    }

    public function update(UpdateEmployeeAdvanceRequest $request, EmployeeAdvance $employeeAdvance)
    {
        // Recovered amount and remaining amount are not editable here
        $data = $request->validated();
        $employeeAdvance->update($data);
        return new EmployeeAdvanceResource($employeeAdvance->load(['employee', 'createdBy']));
    }

    public function recover(RecoverEmployeeAdvanceRequest $request, EmployeeAdvance $employeeAdvance)
    {
        if ($employeeAdvance->status == EmployeeAdvance::STATUS_CANCELLED) {
            return response()->json(['message' => 'Cannot recover a cancelled advance.'], 422);
        }
        
        if ($employeeAdvance->status == EmployeeAdvance::STATUS_RECOVERED) {
            return response()->json(['message' => 'Advance is already fully recovered.'], 422);
        }

        $recoveryAmount = $request->validated()['recovery_amount'];

        if ($recoveryAmount > $employeeAdvance->remaining_amount) {
            return response()->json(['message' => 'Recovery amount cannot exceed remaining amount.'], 422);
        }

        // Recovery Date (current date of actual recovery transaction) 
        // We can check if recovery happens in the same month as advance_date
        $recoveryAttemptDate = \Carbon\Carbon::now();

        if ($recoveryAttemptDate->format('Y-m') !== $employeeAdvance->advance_date->format('Y-m')) {
            return response()->json([
                'message' => 'Advance must be settled in the same month it was taken. Advance month is ' . $employeeAdvance->advance_date->format('F Y') . '.'
            ], 422);
        }

        $employeeAdvance->recovered_amount += $recoveryAmount;
        // Remaining amount and status are calculated automatically in the model's boot method
        $employeeAdvance->save();

        return new EmployeeAdvanceResource($employeeAdvance->load(['employee', 'createdBy']));
    }

    public function cancel(Request $request, EmployeeAdvance $employeeAdvance)
    {
        if ($employeeAdvance->recovered_amount > 0) {
            return response()->json(['message' => 'Cannot cancel an advance that has partial recoveries.'], 422);
        }

        $employeeAdvance->status = EmployeeAdvance::STATUS_CANCELLED;
        // Skip normal calculation for remaining_amount on cancel if needed, 
        // but model boot handles STATUS_CANCELLED gracefully.
        $employeeAdvance->save();

        return response()->json(['message' => 'Advance cancelled successfully.']);
    }

    public function employeeAdvances(Request $request, Employee $employee)
    {
        $query = EmployeeAdvance::where('employee_id', $employee->id)->with(['employee', 'createdBy']);

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        $advances = $query->latest('advance_date')->orderBy('id', 'desc')->paginate($perPage);

        return EmployeeAdvanceResource::collection($advances);
    }
}
