<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\EmployeeDocument;
use App\Http\Requests\StoreEmployeeDocumentRequest;
use App\Http\Requests\UpdateEmployeeDocumentRequest;
use App\Http\Resources\EmployeeDocumentResource;
use Illuminate\Http\Request;

class EmployeeDocumentController extends Controller
{
    public function index(Request $request)
    {
        $query = EmployeeDocument::with('employee');
        $plantIds = $request->user()->accessiblePlantIds();
        if ($plantIds !== null) $query->whereHas('employee', fn ($employees) => $employees->whereIn('plant_id', $plantIds));
        if ($request->filled('employee_id')) $query->where('employee_id', $request->integer('employee_id'));
        $documents = $query->paginate(15);
        return EmployeeDocumentResource::collection($documents);
    }

    public function store(StoreEmployeeDocumentRequest $request)
    {
        $data = $request->validated();
        $employee = \App\Models\Employee::find($data['employee_id'] ?? null);
        if (!$request->user()->canAccessPlant($employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this employee.'], 403);
        }

        if ($request->hasFile('document_file')) {
            $data['document_file'] = $request->file('document_file')->store('employee_documents', 'public');
        }

        $document = EmployeeDocument::create($data);
        return new EmployeeDocumentResource($document->load('employee'));
    }

    public function show(Request $request, EmployeeDocument $employeeDocument)
    {
        if (!$request->user()->canAccessPlant($employeeDocument->employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this document.'], 403);
        }
        return new EmployeeDocumentResource($employeeDocument->load('employee'));
    }

    public function update(UpdateEmployeeDocumentRequest $request, EmployeeDocument $employeeDocument)
    {
        if (!$request->user()->canAccessPlant($employeeDocument->employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this document.'], 403);
        }
        $data = $request->validated();
        if (array_key_exists('employee_id', $data)) {
            $employee = \App\Models\Employee::find($data['employee_id']);
            if (!$request->user()->canAccessPlant($employee?->plant_id)) {
                return response()->json(['message' => 'You do not have access to this employee.'], 403);
            }
        }

        if ($request->hasFile('document_file')) {
            if ($employeeDocument->document_file) {
                \Illuminate\Support\Facades\Storage::disk('public')->delete($employeeDocument->document_file);
            }
            $data['document_file'] = $request->file('document_file')->store('employee_documents', 'public');
        }

        $employeeDocument->update($data);
        return new EmployeeDocumentResource($employeeDocument->load('employee'));
    }

    public function destroy(Request $request, EmployeeDocument $employeeDocument)
    {
        if (!$request->user()->canAccessPlant($employeeDocument->employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this document.'], 403);
        }
        $employeeDocument->delete();
        return response()->json(['message' => 'Employee document deleted successfully']);
    }
}
