<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\EmployeeBankAccount;
use App\Http\Requests\StoreEmployeeBankAccountRequest;
use App\Http\Requests\UpdateEmployeeBankAccountRequest;
use App\Http\Resources\EmployeeBankAccountResource;
use Illuminate\Http\Request;

class EmployeeBankAccountController extends Controller
{
    public function index(Request $request)
    {
        $query = EmployeeBankAccount::with('employee');
        $plantIds = $request->user()->accessiblePlantIds();
        if ($plantIds !== null) $query->whereHas('employee', fn ($employees) => $employees->whereIn('plant_id', $plantIds));
        if ($request->filled('employee_id')) $query->where('employee_id', $request->integer('employee_id'));
        $accounts = $query->paginate(15);
        return EmployeeBankAccountResource::collection($accounts);
    }

    public function store(StoreEmployeeBankAccountRequest $request)
    {
        $employee = \App\Models\Employee::find($request->validated()['employee_id'] ?? null);
        if (!$request->user()->canAccessPlant($employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this employee.'], 403);
        }
        $account = EmployeeBankAccount::create($request->validated());
        return new EmployeeBankAccountResource($account->load('employee'));
    }

    public function show(Request $request, EmployeeBankAccount $employeeBankAccount)
    {
        if (!$request->user()->canAccessPlant($employeeBankAccount->employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this account.'], 403);
        }
        return new EmployeeBankAccountResource($employeeBankAccount->load('employee'));
    }

    public function update(UpdateEmployeeBankAccountRequest $request, EmployeeBankAccount $employeeBankAccount)
    {
        if (!$request->user()->canAccessPlant($employeeBankAccount->employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this account.'], 403);
        }
        $employee = \App\Models\Employee::find($request->validated()['employee_id'] ?? $employeeBankAccount->employee_id);
        if (!$request->user()->canAccessPlant($employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this employee.'], 403);
        }
        $employeeBankAccount->update($request->validated());
        return new EmployeeBankAccountResource($employeeBankAccount->load('employee'));
    }

    public function destroy(Request $request, EmployeeBankAccount $employeeBankAccount)
    {
        if (!$request->user()->canAccessPlant($employeeBankAccount->employee?->plant_id)) {
            return response()->json(['message' => 'You do not have access to this account.'], 403);
        }
        $employeeBankAccount->delete();
        return response()->json(['message' => 'Employee bank account deleted successfully']);
    }
}
