<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Employee;
use App\Models\Shift;
use App\Services\AttendanceService;
use Illuminate\Http\Request;
use App\Http\Requests\StoreAttendanceRequest;
use App\Http\Requests\UpdateAttendanceRequest;
use Carbon\Carbon;

class AttendanceController extends Controller
{
    protected AttendanceService $service;

    public function __construct(AttendanceService $service)
    {
        $this->service = $service;
    }

    public function index(Request $request)
    {
        $query = Attendance::with(['employee', 'workingPlant', 'department', 'designation', 'shift']);
        
        if ($request->has('date_from') && $request->has('date_to')) {
            $query->whereBetween('attendance_date', [$request->date_from, $request->date_to]);
        }
        
        if ($request->has('employee_id')) {
            $query->where('employee_id', $request->employee_id);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        return response()->json($query->paginate($perPage));
    }

    public function store(StoreAttendanceRequest $request)
    {
        $request->validated();

        $employee = Employee::findOrFail($request->employee_id);
        $shift = Shift::findOrFail($request->shift_id);

        // Calculate hours
        $hours = $this->service->calculateHours($request->check_in, $request->check_out, $shift, $request->working_plant_id, $request->attendance_date);

        $attendance = Attendance::create([
            'employee_id' => $employee->id,
            'home_plant_id' => $employee->plant_id, // Home plant is fetched from employee
            'working_plant_id' => $request->working_plant_id,
            'department_id' => $request->department_id,
            'designation_id' => $request->designation_id,
            'shift_id' => $request->shift_id,
            'attendance_date' => $request->attendance_date,
            'check_in' => $request->check_in,
            'check_out' => $request->check_out,
            'actual_worked_hours' => $hours['actual'],
            'regular_hours' => $hours['regular'],
            'overtime_hours' => $hours['overtime'],
            'late_minutes' => $hours['late_minutes'],
            'status' => Attendance::STATUS_PRESENT,
            'workflow_status' => Attendance::WORKFLOW_MARKED,
            'marked_by' => $request->user()->id,
            'marked_at' => now(),
            'remarks' => $request->remarks
        ]);

        return response()->json($attendance, 201);
    }

    public function show(Attendance $attendance)
    {
        return response()->json($attendance->load(['employee', 'workingPlant', 'department', 'designation', 'shift']));
    }

    public function update(UpdateAttendanceRequest $request, Attendance $attendance)
    {
        $request->validated();
        
        $shift = $attendance->shift;
        $hours = $this->service->calculateHours($request->check_in, $request->check_out, $shift, $attendance->working_plant_id, $attendance->attendance_date->toDateString());

        $attendance->update([
            'check_in' => $request->check_in,
            'check_out' => $request->check_out,
            'actual_worked_hours' => $hours['actual'],
            'regular_hours' => $hours['regular'],
            'overtime_hours' => $hours['overtime'],
            'late_minutes' => $hours['late_minutes'],
            'remarks' => $request->remarks
        ]);

        return response()->json($attendance);
    }
    
    public function pendingVerification(Request $request)
    {
        $query = Attendance::with(['employee', 'workingPlant', 'department', 'designation', 'shift'])
            ->where('workflow_status', Attendance::WORKFLOW_MARKED);

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;
            
        return response()->json($query->paginate($perPage));
    }
    
    public function verify(Request $request, Attendance $attendance)
    {
        if ($attendance->workflow_status === Attendance::WORKFLOW_VERIFIED) {
            return response()->json(['message' => 'Attendance is already verified'], 422);
        }
        
        $attendance->update([
            'workflow_status' => Attendance::WORKFLOW_VERIFIED,
            'verified_by' => $request->user()->id,
            'verified_at' => now()
        ]);
        
        return response()->json(['message' => 'Verified successfully', 'attendance' => $attendance]);
    }
    
    public function reject(Request $request, Attendance $attendance)
    {
        $request->validate(['rejection_reason' => 'required|string']);
        
        $attendance->update([
            'workflow_status' => Attendance::WORKFLOW_REJECTED,
            'verified_by' => $request->user()->id,
            'verified_at' => now(),
            'rejection_reason' => $request->rejection_reason
        ]);
        
        return response()->json(['message' => 'Rejected successfully', 'attendance' => $attendance]);
    }
}
