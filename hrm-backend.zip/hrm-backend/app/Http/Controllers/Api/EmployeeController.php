<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Http\Requests\StoreEmployeeRequest;
use App\Http\Requests\UpdateEmployeeRequest;
use App\Http\Resources\EmployeeResource;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index(Request $request)
    {
        $query = Employee::with(['plant', 'department', 'designation', 'shift', 'charges']);
        
        $plantIds = $request->user()->accessiblePlantIds();
        if ($plantIds !== null) {
            $query->whereIn('plant_id', $plantIds);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('employee_code', 'like', "%{$search}%");
            });
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        // Ensure backward compatibility in case the frontend still explicitly requests 'all'
        if ($request->has('all') && $request->all === 'true') {
            return EmployeeResource::collection($query->get());
        }

        $employees = $query->orderBy('name')->orderBy('id')->paginate($perPage);
        return EmployeeResource::collection($employees);
    }

    public function store(StoreEmployeeRequest $request)
    {
        $data = $request->validated();
        if (!$request->user()->canAccessPlant($data['plant_id'] ?? null)) {
            return response()->json(['message' => 'You do not have access to this plant.'], 403);
        }

        // Generate employee_code automatically
        $latestEmployee = Employee::orderBy('id', 'desc')->first();
        $nextId = $latestEmployee ? $latestEmployee->id + 1 : 1;
        $data['employee_code'] = 'EMP-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);

        // Handle image upload
        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('employees', 'public');
        }

        $employee = Employee::create($data);

        // Attach charges if provided
        if (isset($data['charge_ids'])) {
            $employee->charges()->sync($data['charge_ids']);
        }

        // Return with relationships loaded
        return new EmployeeResource($employee->load(['plant', 'department', 'designation', 'shift', 'charges']));
    }

    public function show(Request $request, Employee $employee)
    {
        if (!$request->user()->canAccessPlant($employee->plant_id)) {
            return response()->json(['message' => 'You do not have access to this employee.'], 403);
        }
        return new EmployeeResource($employee->load(['plant', 'department', 'designation', 'shift', 'charges']));
    }

    public function update(UpdateEmployeeRequest $request, Employee $employee)
    {
        if (!$request->user()->canAccessPlant($employee->plant_id)) {
            return response()->json(['message' => 'You do not have access to this employee.'], 403);
        }
        $data = $request->validated();
        if (array_key_exists('plant_id', $data) && !$request->user()->canAccessPlant($data['plant_id'])) {
            return response()->json(['message' => 'You do not have access to this plant.'], 403);
        }

        // Handle image upload
        if ($request->hasFile('image')) {
            if ($employee->image) {
                \Illuminate\Support\Facades\Storage::disk('public')->delete($employee->image);
            }
            $data['image'] = $request->file('image')->store('employees', 'public');
        }

        $employee->update($data);

        // Sync charges if provided in the request
        if (array_key_exists('charge_ids', $data)) {
            $employee->charges()->sync($data['charge_ids']);
        }

        return new EmployeeResource($employee->load(['plant', 'department', 'designation', 'shift', 'charges']));
    }

    public function destroy(Request $request, Employee $employee)
    {
        if (!$request->user()->canAccessPlant($employee->plant_id)) {
            return response()->json(['message' => 'You do not have access to this employee.'], 403);
        }
        $employee->delete();
        return response()->json(['message' => 'Employee deleted successfully']);
    }
}
