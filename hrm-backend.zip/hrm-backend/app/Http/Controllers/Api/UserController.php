<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\Employee;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        $user = $request->user();
        $plantIds = $user->accessiblePlantIds();
        $query = User::query();
        if ($plantIds !== null) {
            $query->whereHas('employee', fn ($employees) => $employees->whereIn('plant_id', $plantIds));
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('username', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        return UserResource::collection(
            $query
                ->select(['id', 'name', 'username', 'email', 'status', 'role_id', 'employee_id', 'created_at'])
                ->with(['role:id,name,description', 'employee'])
                ->orderBy('name')
                ->orderBy('id')
                ->paginate($perPage)
        );
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'     => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:users,username',
            'email'    => 'nullable|email|max:255|unique:users,email',
            'password' => 'required|string|min:8',
            'role_id'  => 'required|exists:roles,id',
            'employee_id' => 'nullable|exists:employees,id',
            'status'   => 'required|boolean',
        ]);

        $data['password'] = Hash::make($data['password']);
        $data['email']    = $data['email'] ?: null;

        if (!empty($data['employee_id'])) {
            $employee = Employee::find($data['employee_id']);
            if (!$request->user()->canAccessPlant($employee?->plant_id)) {
                return response()->json(['message' => 'You do not have access to this employee.'], 403);
            }
        }

        return new UserResource(User::create($data)->load(['role.permissions', 'employee']));
    }

    public function show(User $user)
    {
        return new UserResource($user->load(['role.permissions', 'employee']));
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name'     => 'sometimes|required|string|max:255',
            'username' => ['sometimes', 'required', 'string', 'max:255',
                           Rule::unique('users', 'username')->ignore($user->id)],
            'email'    => ['nullable', 'email', 'max:255',
                           Rule::unique('users', 'email')->ignore($user->id)],
            'password' => 'nullable|string|min:8',
            'role_id'  => 'sometimes|required|exists:roles,id',
            'employee_id' => 'nullable|exists:employees,id',
            'status'   => 'sometimes|boolean',
        ]);

        if (!empty($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data['password']);
        }

        if (array_key_exists('email', $data)) {
            $data['email'] = $data['email'] ?: null;
        }

        if (array_key_exists('employee_id', $data) && !empty($data['employee_id'])) {
            $employee = Employee::find($data['employee_id']);
            if (!$request->user()->canAccessPlant($employee?->plant_id)) {
                return response()->json(['message' => 'You do not have access to this employee.'], 403);
            }
        }

        $user->update($data);
        return new UserResource($user->load(['role.permissions', 'employee']));
    }

    public function destroy(Request $request, User $user)
    {
        if ($request->user()->id === $user->id) {
            return response()->json(['message' => 'You cannot delete your own account.'], 422);
        }
        $user->delete();
        return response()->json(['message' => 'User deleted successfully']);
    }
}
