<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StorePlantRequest;
use App\Http\Requests\UpdatePlantRequest;
use App\Http\Resources\PlantResource;
use App\Models\Plant;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class PlantController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Plant::query();
        
        $plantIds = $request->user()->accessiblePlantIds();
        if ($plantIds !== null) {
            $query->whereIn('id', $plantIds);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where('name', 'like', "%{$search}%");
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        $plants = $query->orderBy('name')->orderBy('id')->paginate($perPage);
        return PlantResource::collection($plants);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePlantRequest $request)
    {
        if ($request->user()->accessiblePlantIds() !== null) {
            return response()->json(['message' => 'Only the system administrator can create plants.'], 403);
        }
        $plant = Plant::create($request->validated());
        return new PlantResource($plant);
    }

    /**
     * Display the specified resource.
     */
    public function show(Request $request, Plant $plant)
    {
        if (!$request->user()->canAccessPlant($plant->id)) {
            return response()->json(['message' => 'You do not have access to this plant.'], 403);
        }
        return new PlantResource($plant);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePlantRequest $request, Plant $plant)
    {
        if (!$request->user()->canAccessPlant($plant->id)) {
            return response()->json(['message' => 'You do not have access to this plant.'], 403);
        }
        $plant->update($request->validated());
        return new PlantResource($plant);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, Plant $plant)
    {
        if (!$request->user()->canAccessPlant($plant->id)) {
            return response()->json(['message' => 'You do not have access to this plant.'], 403);
        }
        $plant->delete();
        return response()->json(['message' => 'Plant deleted successfully']);
    }
}
