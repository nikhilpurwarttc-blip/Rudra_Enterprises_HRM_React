<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Designation;
use App\Http\Requests\StoreDesignationRequest;
use App\Http\Requests\UpdateDesignationRequest;
use App\Http\Resources\DesignationResource;

class DesignationController extends Controller
{
    public function index(\Illuminate\Http\Request $request)
    {
        $query = Designation::query();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where('name', 'like', "%{$search}%");
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        return DesignationResource::collection($query->orderBy('name')->orderBy('id')->paginate($perPage));
    }

    public function store(StoreDesignationRequest $request)
    {
        $designation = Designation::create($request->validated());
        return new DesignationResource($designation);
    }

    public function show(Designation $designation)
    {
        return new DesignationResource($designation);
    }

    public function update(UpdateDesignationRequest $request, Designation $designation)
    {
        $designation->update($request->validated());
        return new DesignationResource($designation);
    }

    public function destroy(Designation $designation)
    {
        $designation->delete();
        return response()->json(['message' => 'Designation deleted successfully']);
    }
}
