<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Http\Requests\StoreRoleRequest;
use App\Http\Requests\UpdateRoleRequest;
use App\Http\Resources\RoleResource;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    public function index(Request $request)
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        $query = Role::with(['permissions', 'plants'])
            ->when($allowedPlantIds !== null, fn ($query) => $query->where(function ($query) use ($allowedPlantIds) {
                $query->whereDoesntHave('plants')->orWhereHas('plants', fn ($plants) => $plants->whereIn('plants.id', $allowedPlantIds));
            }))
            ->withCount('users');

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where('name', 'like', "%{$search}%");
        }

        if ($request->filled('ids')) {
            $query->whereIn('id', (array) $request->ids);
        }

        $perPage = (int) $request->input('per_page', 15);
        if ($perPage > 100) $perPage = 100;
        if ($perPage < 1) $perPage = 15;

        return RoleResource::collection($query->orderBy('name')->orderBy('id')->paginate($perPage));
    }

    public function store(StoreRoleRequest $request)
    {
        $data = $request->validated();
        $ids = $this->parsePermissionIds($data['permissions'] ?? []);
        $plantIds = $this->parseIds($data['plant_ids'] ?? []);
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && array_diff($plantIds, $allowedPlantIds)) {
            return response()->json(['message' => 'You do not have access to one or more selected plants.'], 403);
        }
        unset($data['permissions']);
        unset($data['plant_ids']);

        $role = DB::transaction(function () use ($data, $ids, $plantIds) {
            $role = Role::create($data);
            $role->permissions()->sync($ids);
            $role->plants()->sync($plantIds);
            return $role;
        });

        return new RoleResource($role->load(['permissions', 'plants'])->loadCount('users'));
    }

    public function show(Request $request, Role $role)
    {
        if (!$this->canAccessRole($request, $role)) {
            return response()->json(['message' => 'You do not have access to this role.'], 403);
        }
        return new RoleResource($role->load(['permissions', 'plants'])->loadCount('users'));
    }

    public function update(UpdateRoleRequest $request, Role $role)
    {
        if (!$this->canAccessRole($request, $role)) {
            return response()->json(['message' => 'You do not have access to this role.'], 403);
        }
        $data = $request->validated();
        $hasPermissions = array_key_exists('permissions', $data);
        $ids = $this->parsePermissionIds($data['permissions'] ?? []);
        $hasPlants = array_key_exists('plant_ids', $data);
        $plantIds = $this->parseIds($data['plant_ids'] ?? []);
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && array_diff($plantIds, $allowedPlantIds)) {
            return response()->json(['message' => 'You do not have access to one or more selected plants.'], 403);
        }
        unset($data['permissions']);
        unset($data['plant_ids']);

        DB::transaction(function () use ($data, $hasPermissions, $ids, $hasPlants, $plantIds, $role) {
            if (!empty($data)) {
                $role->update($data);
            }

            // sync permissions whenever the key is present (even empty array = remove all)
            if ($hasPermissions) {
                $role->permissions()->sync($ids);
            }
            if ($hasPlants) {
                $role->plants()->sync($plantIds);
            }
        });

        return new RoleResource($role->load(['permissions', 'plants'])->loadCount('users'));
    }

    public function destroy(Role $role)
    {
        $userCount = $role->users()->count();
        if ($userCount > 0) {
            return response()->json([
                'message' => "Cannot delete: {$userCount} user(s) are assigned to this role.",
            ], 422);
        }

        $role->delete();
        return response()->json(['message' => 'Role deleted successfully']);
    }

    /**
     * Parse and sanitise permission IDs from request input.
     * Accepts array of ints or strings, returns array of positive ints.
     */
    private function parsePermissionIds(mixed $input): array
    {
        if (!is_array($input)) return [];

        return collect($input)
            ->map(fn($id) => (int) $id)
            ->filter(fn($id) => $id > 0)
            ->unique()
            ->values()
            ->toArray();
    }

    private function parseIds(mixed $input): array
    {
        if (!is_array($input)) return [];

        return collect($input)
            ->map(fn ($id) => (int) $id)
            ->filter(fn ($id) => $id > 0)
            ->unique()
            ->values()
            ->toArray();
    }

    private function canAccessRole(Request $request, Role $role): bool
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        return $allowedPlantIds === null
            || !$role->plants()->exists()
            || $role->plants()->whereIn('plants.id', $allowedPlantIds)->exists();
    }
}
