<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Holiday;
use App\Http\Requests\StoreHolidayRequest;
use App\Http\Requests\UpdateHolidayRequest;
use App\Http\Resources\HolidayResource;
use Illuminate\Http\Request;

class HolidayController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Holiday::with('plants');
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null) {
            $query->whereHas('plants', fn ($plants) => $plants->whereIn('holiday_plant.plant_id', $allowedPlantIds));
        }

        if (request()->has('plant_id')) {
            $plantIds = request('plant_id');
            
            // Handle both array input and comma-separated string (e.g. ?plant_id=1,2)
            if (is_string($plantIds)) {
                $plantIds = explode(',', $plantIds);
            }
            
            $query->whereHas('plants', function($q) use ($plantIds) {
                $q->whereIn('holiday_plant.plant_id', (array) $plantIds);
            });
        }

        return HolidayResource::collection($query->paginate(15));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreHolidayRequest $request)
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        $plantIds = (array) $request->input('plant_id', []);
        if ($allowedPlantIds !== null && array_diff($plantIds, $allowedPlantIds)) {
            return response()->json(['message' => 'You do not have access to one or more selected plants.'], 403);
        }
        $holiday = Holiday::create($request->validated());
        if ($request->has('plant_id')) {
            $holiday->plants()->attach($request->plant_id);
        }
        return new HolidayResource($holiday->load('plants'));
    }

    /**
     * Display the specified resource.
     */
    public function show(Request $request, Holiday $holiday)
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && !$holiday->plants()->whereIn('plants.id', $allowedPlantIds)->exists()) {
            return response()->json(['message' => 'You do not have access to this holiday.'], 403);
        }
        return new HolidayResource($holiday->load('plants'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateHolidayRequest $request, Holiday $holiday)
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && !$holiday->plants()->whereIn('plants.id', $allowedPlantIds)->exists()) {
            return response()->json(['message' => 'You do not have access to this holiday.'], 403);
        }
        $plantIds = (array) $request->input('plant_id', []);
        if ($allowedPlantIds !== null && array_diff($plantIds, $allowedPlantIds)) {
            return response()->json(['message' => 'You do not have access to one or more selected plants.'], 403);
        }
        $holiday->update($request->validated());
        if ($request->has('plant_id')) {
            $holiday->plants()->sync($request->plant_id);
        }
        return new HolidayResource($holiday->load('plants'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, Holiday $holiday)
    {
        $allowedPlantIds = $request->user()->accessiblePlantIds();
        if ($allowedPlantIds !== null && !$holiday->plants()->whereIn('plants.id', $allowedPlantIds)->exists()) {
            return response()->json(['message' => 'You do not have access to this holiday.'], 403);
        }
        $holiday->plants()->detach();
        $holiday->delete();
        return response()->json(['message' => 'Holiday deleted successfully']);
    }
}
