<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class StoreEmployeeDocumentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'employee_id' => 'required|exists:employees,id',
            'document_type' => 'required|string|max:255',
            'document_number' => 'required|string|max:255',
            'document_file' => 'nullable|file|mimes:jpeg,png,jpg,gif,pdf|max:5120',
            'status' => 'nullable|boolean',
        ];
    }
}
