<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreDepartmentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'plant_id' => 'required|array|min:1',
            'plant_id.*' => 'integer|exists:plants,id',
            'department_code' => 'required|string|max:255|unique:departments,department_code',
            'name' => 'required|string|max:255',
            'status' => 'nullable|boolean',
        ];
    }
}
