<?php

namespace App\Http\Requests;

use App\Models\EmployeeAdvance;
use Illuminate\Foundation\Http\FormRequest;

class UpdateEmployeeAdvanceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'advance_date' => 'sometimes|required|date',
            'amount' => 'sometimes|required|numeric|min:0.01',
            'payment_mode' => 'sometimes|required|in:' . EmployeeAdvance::PAYMENT_CASH . ',' . EmployeeAdvance::PAYMENT_BANK,
            'purpose' => 'nullable|string',
            'remarks' => 'nullable|string',
        ];
    }
}
