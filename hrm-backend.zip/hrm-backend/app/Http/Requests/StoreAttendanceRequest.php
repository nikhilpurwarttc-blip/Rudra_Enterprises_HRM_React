<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreAttendanceRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'employee_id' => 'required|exists:employees,id',
            'working_plant_id' => 'required|exists:plants,id',
            'department_id' => 'required|exists:departments,id',
            'designation_id' => 'required|exists:designations,id',
            'shift_id' => 'required|exists:shifts,id',
            'attendance_date' => 'required|date',
            'check_in' => 'required|date',
            'check_out' => 'required|date|after:check_in',
            'remarks' => 'nullable|string'
        ];
    }
}
