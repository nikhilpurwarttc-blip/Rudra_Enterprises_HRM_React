<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RecoverEmployeeAdvanceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'recovery_amount' => 'required|numeric|min:0.01',
            'settlement_date' => 'nullable|date',
        ];
    }
}
