<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateHolidayRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'plant_id' => 'sometimes|required|array',
            'plant_id.*' => 'integer|exists:plants,id',
            'name' => 'sometimes|required|string|max:255',
            'holiday_date' => 'sometimes|required|date',
            'description' => 'nullable|string',
            'status' => 'nullable|boolean',
        ];
    }
}
