<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'sometimes|required|string|max:255',
            'dob' => 'nullable|date',
            'joining_date' => 'nullable|date',
            'plant_id' => 'nullable|exists:plants,id',
            'department_id' => 'nullable|exists:departments,id',
            'designation_id' => 'nullable|exists:designations,id',
            'status' => 'nullable|boolean',
            'mobile_number' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'address' => 'nullable|string',
            'gender' => 'nullable|string',
            'marital_status' => 'nullable|string',
            'shift_id' => 'nullable|exists:shifts,id',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'charge_ids' => 'nullable|array',
            'charge_ids.*' => 'exists:charges,id'
        ];
    }
}
