<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\PlantShutdown;

class UpdatePlantShutdownRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'plant_id' => 'required|exists:plants,id',
            'shutdown_date' => 'required|date',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'reason' => 'required|string',
            'shutdown_type' => 'nullable|string',
            'remarks' => 'nullable|string',
        ];
    }

    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            $shutdown = $this->route('plant_shutdown');
            if ($shutdown && $this->has(['plant_id', 'shutdown_date', 'start_time', 'end_time'])) {
                $overlap = PlantShutdown::where('plant_id', $this->plant_id)
                    ->where('shutdown_date', $this->shutdown_date)
                    ->where('id', '!=', $shutdown->id)
                    ->where(function ($q) {
                        $q->whereBetween('start_time', [$this->start_time, $this->end_time])
                          ->orWhereBetween('end_time', [$this->start_time, $this->end_time])
                          ->orWhere(function ($q2) {
                              $q2->where('start_time', '<=', $this->start_time)
                                 ->where('end_time', '>=', $this->end_time);
                          });
                    })
                    ->exists();

                if ($overlap) {
                    $validator->errors()->add('time', 'Overlapping shutdown already exists for this plant and date.');
                }
            }
        });
    }
}
