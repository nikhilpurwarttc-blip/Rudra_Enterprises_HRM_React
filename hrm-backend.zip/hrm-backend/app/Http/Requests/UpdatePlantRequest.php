<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdatePlantRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        $plantId = $this->route('plant') ? $this->route('plant')->id : null;

        return [
            'plant_code' => 'sometimes|required|string|max:255|unique:plants,plant_code,' . $plantId,
            'name' => 'sometimes|required|string|max:255',
            'address' => 'nullable|string',
            'status' => 'sometimes|required|in:0,1,2',
        ];
    }
}
