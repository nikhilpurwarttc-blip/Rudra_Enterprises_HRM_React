<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateRoleRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $roleId = $this->route('role') ? $this->route('role')->id : null;
        
        return [
            'name' => 'sometimes|required|string|max:255|unique:roles,name,' . $roleId,
            'description' => 'nullable|string',
            'status' => 'sometimes|required|boolean',
            'permissions' => 'nullable|array',
            'permissions.*' => 'exists:permissions,id',
            'plant_ids' => 'nullable|array',
            'plant_ids.*' => 'integer|exists:plants,id',
        ];
    }
}
