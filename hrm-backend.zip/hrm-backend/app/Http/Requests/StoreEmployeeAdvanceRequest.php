<?php

namespace App\Http\Requests;

use App\Models\EmployeeAdvance;
use Illuminate\Foundation\Http\FormRequest;

class StoreEmployeeAdvanceRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'employee_id' => 'required|exists:employees,id',
            'advance_date' => 'required|date',
            'amount' => 'required|numeric|min:0.01',
            'payment_mode' => 'required|in:' . EmployeeAdvance::PAYMENT_CASH . ',' . EmployeeAdvance::PAYMENT_BANK,
            'purpose' => 'nullable|string',
            'remarks' => 'nullable|string',
        ];
    }
}
