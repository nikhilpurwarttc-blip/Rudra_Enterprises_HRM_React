<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdatePermissionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $permissionId = $this->route('permission') ? $this->route('permission')->id : null;
        
        return [
            'name' => 'sometimes|required|string|max:255|unique:permissions,name,' . $permissionId,
            'module' => 'sometimes|required|string|max:255',
            'action' => 'sometimes|required|string|max:255',
        ];
    }
}
