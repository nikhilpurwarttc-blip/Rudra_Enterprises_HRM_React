<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateDesignationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => 'sometimes|required|string|max:255|unique:designations,name,' . $this->designation->id,
            'description' => 'nullable|string',
            'status' => 'nullable|boolean',
        ];
    }
}
