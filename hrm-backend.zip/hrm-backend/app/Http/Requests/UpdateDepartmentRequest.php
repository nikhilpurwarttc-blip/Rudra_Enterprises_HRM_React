<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateDepartmentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'plant_id' => 'sometimes|required|array|min:1',
            'plant_id.*' => 'integer|exists:plants,id',
            'department_code' => 'sometimes|required|string|max:255|unique:departments,department_code,' . $this->department->id,
            'name' => 'sometimes|required|string|max:255',
            'status' => 'nullable|boolean',
        ];
    }
}
