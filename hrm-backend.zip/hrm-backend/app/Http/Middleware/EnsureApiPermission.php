<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureApiPermission
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        $routeName = (string) $request->route()?->getName();
        $module = str($routeName)->before('.')->toString();

        $action = match ($request->method()) {
            'GET', 'HEAD' => 'view',
            'POST' => 'create',
            'PUT', 'PATCH' => 'edit',
            'DELETE' => 'delete',
            default => null,
        };

        if (!$user || !$action || !$module || $user->isSuperAdmin() || $user->hasPermission($module, $action)) {
            return $next($request);
        }

        return response()->json(['message' => 'You do not have permission to perform this action.'], 403);
    }
}