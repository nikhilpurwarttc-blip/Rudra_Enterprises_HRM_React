<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployeeAdvance extends Model
{
    // Payment Mode Constants
    public const PAYMENT_CASH = 1;
    public const PAYMENT_BANK = 2;

    // Status Constants
    public const STATUS_PENDING = 1;
    public const STATUS_RECOVERED = 2;
    public const STATUS_CANCELLED = 3;

    protected $fillable = [
        'employee_id',
        'advance_date',
        'amount',
        'payment_mode',
        'purpose',
        'recovered_amount',
        'remaining_amount',
        'status',
        'remarks',
        'created_by',
        'settlement_date',
    ];

    protected $casts = [
        'advance_date' => 'date',
        'settlement_date' => 'date',
        'amount' => 'decimal:2',
        'recovered_amount' => 'decimal:2',
        'remaining_amount' => 'decimal:2',
    ];

    protected static function boot()
    {
        parent::boot();

        static::saving(function ($advance) {
            // Auto-calculate remaining amount
            $advance->remaining_amount = $advance->amount - $advance->recovered_amount;

            // Auto-update status based on remaining amount (unless it's cancelled)
            if ($advance->status != self::STATUS_CANCELLED) {
                if ($advance->remaining_amount <= 0) {
                    $advance->status = self::STATUS_RECOVERED;
                } else {
                    $advance->status = self::STATUS_PENDING;
                }
            }
        });
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
