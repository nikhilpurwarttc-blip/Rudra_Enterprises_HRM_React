<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'username',
        'email',
        'password',
        'role_id',
        'status',
        'employee_id',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function isSuperAdmin(): bool
    {
        return $this->role()
            ->whereRaw("LOWER(REPLACE(REPLACE(REPLACE(name, ' ', ''), '-', ''), '_', '')) = ?", ['superadmin'])
            ->exists();
    }

    public function hasPermission(string $module, string $action): bool
    {
        return $this->role()
            ->whereHas('permissions', fn ($query) => $query
                ->where('module', $module)
                ->where('action', $action))
            ->exists();
    }

    /**
     * Return assigned plant IDs, or null when the user can access every plant.
     */
    public function accessiblePlantIds(): ?array
    {
        if ($this->isSuperAdmin()) {
            return null;
        }

        return $this->role()->with('plants')->first()?->plants->pluck('id')->map(fn ($id) => (int) $id)->all() ?? [];
    }

    public function canAccessPlant(?int $plantId): bool
    {
        if (!$plantId) return false;

        $plantIds = $this->accessiblePlantIds();
        return $plantIds === null || in_array($plantId, $plantIds, true);
    }
}
