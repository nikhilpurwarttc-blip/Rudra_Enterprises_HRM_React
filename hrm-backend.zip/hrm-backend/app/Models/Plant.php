<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Plant extends Model
{
    protected $fillable = [
        'plant_code',
        'name',
        'address',
        'status',
    ];

    public function roles()
    {
        return $this->belongsToMany(Role::class, 'plant_role');
    }
}
