<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attendance extends Model
{
    use HasFactory;

    // Check-in grace period/allowance (minutes)
    public const CHECKIN_ALLOWANCE_MINUTES = 5;

    // Status Constants
    public const STATUS_ABSENT = 0;
    public const STATUS_PRESENT = 1;
    public const STATUS_HALF_DAY = 2;
    public const STATUS_ON_LEAVE = 3;
    public const STATUS_HOLIDAY = 4;
    public const STATUS_WEEKLY_OFF = 5;

    // Workflow Status Constants
    public const WORKFLOW_MARKED = 1;
    public const WORKFLOW_VERIFIED = 2;
    public const WORKFLOW_REJECTED = 3;

    protected $fillable = [
        'employee_id',
        'home_plant_id',
        'working_plant_id',
        'department_id',
        'designation_id',
        'shift_id',
        'attendance_date',
        'check_in',
        'check_out',
        'actual_worked_hours',
        'regular_hours',
        'overtime_hours',
        'late_minutes',
        'early_exit_minutes',
        'status',
        'workflow_status',
        'marked_by',
        'marked_at',
        'verified_by',
        'verified_at',
        'rejection_reason',
        'remarks',
    ];

    protected $casts = [
        'attendance_date' => 'date',
        'check_in' => 'datetime',
        'check_out' => 'datetime',
        'marked_at' => 'datetime',
        'verified_at' => 'datetime',
        'actual_worked_hours' => 'decimal:2',
        'regular_hours' => 'decimal:2',
        'overtime_hours' => 'decimal:2',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function homePlant()
    {
        return $this->belongsTo(Plant::class, 'home_plant_id');
    }

    public function workingPlant()
    {
        return $this->belongsTo(Plant::class, 'working_plant_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function designation()
    {
        return $this->belongsTo(Designation::class);
    }

    public function shift()
    {
        return $this->belongsTo(Shift::class);
    }

    public function markedBy()
    {
        return $this->belongsTo(User::class, 'marked_by');
    }

    public function verifiedBy()
    {
        return $this->belongsTo(User::class, 'verified_by');
    }
}