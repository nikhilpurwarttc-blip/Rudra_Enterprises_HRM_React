<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Holiday extends Model
{
    protected $fillable = [
        'name',
        'holiday_date',
        'description',
        'status',
    ];

    public function plants()
    {
        return $this->belongsToMany(Plant::class);
    }
}
