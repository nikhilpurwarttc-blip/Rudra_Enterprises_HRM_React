<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Charge extends Model
{
    protected $fillable = [
        'deduction',
        'value_type',
        'value',
        'status',
    ];

    public function employees()
    {
        return $this->belongsToMany(Employee::class, 'charge_employee');
    }
}
