<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployeeBankAccount extends Model
{
    protected $fillable = [
        'employee_id',
        'bank_name',
        'account_number',
        'ifsc_code',
        'account_holder_name',
        'is_primary',
        'status',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}
