<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployeeDocument extends Model
{
    protected $fillable = [
        'employee_id',
        'document_type',
        'document_number',
        'document_file',
        'status',
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }
}
