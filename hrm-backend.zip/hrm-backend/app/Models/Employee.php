<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    //
    protected $fillable = [
        'employee_code',
        'name',
        'dob',
        'joining_date',
        'plant_id',
        'department_id',
        'designation_id',
        'status',
        'mobile_number',
        'email',
        'address',
        'gender',
        'marital_status',
        'shift_id',
        'image'
    ];

    public function plant()
    {
        return $this->belongsTo(Plant::class);
    }

    public function department()
    {
        return $this->belongsTo(Department::class);
    }

    public function designation()
    {
        return $this->belongsTo(Designation::class);
    }

    public function shift()
    {
        return $this->belongsTo(Shift::class);
    }

    public function charges()
    {
        return $this->belongsToMany(Charge::class, 'charge_employee');
    }

    public function documents()
    {
        return $this->hasMany(EmployeeDocument::class);
    }

    public function bankAccounts()
    {
        return $this->hasMany(EmployeeBankAccount::class);
    }
}
