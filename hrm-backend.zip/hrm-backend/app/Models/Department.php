<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    //
    protected $fillable = [
        'plant_id',
        'department_code',
        'name',
        'status',
        'created_by'
    ];

    public function plant()
    {
        return $this->belongsTo(Plant::class);
    }

    public function plants()
    {
        return $this->belongsToMany(Plant::class, 'department_plant');
    }
}
