<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('department_plant', function (Blueprint $table) {
            $table->foreignId('department_id')->constrained()->cascadeOnDelete();
            $table->foreignId('plant_id')->constrained()->cascadeOnDelete();
            $table->primary(['department_id', 'plant_id']);
        });

        DB::table('departments')->whereNotNull('plant_id')->orderBy('id')->eachById(function ($department) {
            DB::table('department_plant')->insertOrIgnore([
                'department_id' => $department->id,
                'plant_id' => $department->plant_id,
            ]);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('department_plant');
    }
};