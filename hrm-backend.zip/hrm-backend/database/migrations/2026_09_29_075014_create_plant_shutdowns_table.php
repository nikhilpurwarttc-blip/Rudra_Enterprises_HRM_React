<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('plant_shutdowns', function (Blueprint $table) {
            $table->id();
            $table->foreignId('plant_id')->constrained()->cascadeOnDelete();
            $table->date('shutdown_date');
            $table->time('start_time');
            $table->time('end_time');
            $table->string('reason');
            $table->string('shutdown_type')->nullable();
            $table->decimal('guaranteed_hours', 5, 2)->default(0);
            $table->tinyInteger('status')->default(1)->comment('1: Pending, 2: Approved, 3: Rejected');
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->text('remarks')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plant_shutdowns');
    }
};