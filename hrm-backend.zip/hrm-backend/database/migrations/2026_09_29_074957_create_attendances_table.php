<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('attendances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained()->cascadeOnDelete();
            $table->foreignId('home_plant_id')->constrained('plants')->cascadeOnDelete();
            $table->foreignId('working_plant_id')->constrained('plants')->cascadeOnDelete();
            $table->foreignId('department_id')->constrained()->cascadeOnDelete();
            $table->foreignId('designation_id')->constrained()->cascadeOnDelete();
            $table->foreignId('shift_id')->constrained()->cascadeOnDelete();
            
            $table->date('attendance_date');
            $table->dateTime('check_in')->nullable();
            $table->dateTime('check_out')->nullable();
            
            $table->decimal('actual_worked_hours', 5, 2)->default(0);
            $table->decimal('regular_hours', 5, 2)->default(0);
            $table->decimal('overtime_hours', 5, 2)->default(0);
            $table->integer('late_minutes')->default(0);
            $table->integer('early_exit_minutes')->default(0);
            
            $table->tinyInteger('status')->default(0)->comment('0: Absent, 1: Present, 2: Half Day, 3: On Leave, 4: Holiday, 5: Weekly Off');
            $table->tinyInteger('workflow_status')->default(1)->comment('1: Marked, 2: Verified, 3: Rejected');
            
            $table->foreignId('marked_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('marked_at')->nullable();
            
            $table->foreignId('verified_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('verified_at')->nullable();
            
            $table->text('rejection_reason')->nullable();
            $table->text('remarks')->nullable();
            
            $table->timestamps();
            
            $table->index(['employee_id', 'attendance_date']);
            $table->index('attendance_date');
            $table->index(['working_plant_id', 'attendance_date']);
            $table->index(['home_plant_id', 'attendance_date']);
            $table->index(['department_id', 'attendance_date']);
            $table->index(['shift_id', 'attendance_date']);
            $table->index('status');
            $table->index('workflow_status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attendances');
    }
};