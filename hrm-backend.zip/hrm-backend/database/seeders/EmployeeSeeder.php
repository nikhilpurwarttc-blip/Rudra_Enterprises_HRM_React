<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class EmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $employees = [
            [
                'employee_code' => 'EMP-0001',
                'name' => 'John Doe',
                'dob' => '1990-01-15',
                'joining_date' => '2024-01-10',
                'status' => 0,
                'mobile_number' => '9876543210',
                'gender' => 'Male',
                'marital_status' => 'Single',
            ],
            [
                'employee_code' => 'EMP-0002',
                'name' => 'Jane Smith',
                'dob' => '1992-05-20',
                'joining_date' => '2024-02-15',
                'status' => 0,
                'mobile_number' => '9876543211',
                'gender' => 'Female',
                'marital_status' => 'Married',
            ],
            [
                'employee_code' => 'EMP-0003',
                'name' => 'Robert Brown',
                'dob' => '1988-11-30',
                'joining_date' => '2023-08-01',
                'status' => 0,
                'mobile_number' => '9876543212',
                'gender' => 'Male',
                'marital_status' => 'Married',
            ],
            [
                'employee_code' => 'EMP-0004',
                'name' => 'Emily White',
                'dob' => '1995-07-25',
                'joining_date' => '2024-05-01',
                'status' => 0,
                'mobile_number' => '9876543213',
                'gender' => 'Female',
                'marital_status' => 'Single',
            ],
            [
                'employee_code' => 'EMP-0005',
                'name' => 'Michael Green',
                'dob' => '1985-03-10',
                'joining_date' => '2022-11-20',
                'status' => 0,
                'mobile_number' => '9876543214',
                'gender' => 'Male',
                'marital_status' => 'Married',
            ],
            [
                'employee_code' => 'EMP-0006',
                'name' => 'Sarah Taylor',
                'dob' => '1993-09-05',
                'joining_date' => '2024-03-10',
                'status' => 0,
                'mobile_number' => '9876543215',
                'gender' => 'Female',
                'marital_status' => 'Single',
            ],
            [
                'employee_code' => 'EMP-0007',
                'name' => 'David Wilson',
                'dob' => '1991-12-12',
                'joining_date' => '2023-01-25',
                'status' => 0,
                'mobile_number' => '9876543216',
                'gender' => 'Male',
                'marital_status' => 'Single',
            ]
        ];

        foreach ($employees as $employee) {
            \App\Models\Employee::updateOrCreate(
                ['employee_code' => $employee['employee_code']],
                $employee
            );
        }
    }
}
