<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Role;
use App\Models\User;
use App\Models\Permission;
use App\Models\Plant;
use Illuminate\Support\Facades\Hash;

class SuperAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $role = Role::firstOrCreate(
            ['name' => 'Super Admin'],
            ['description' => 'System Administrator with full access', 'status' => 1]
        );

        // Keep the permission catalog aligned with the frontend route catalog.
        $modules = [
            'dashboard', 'plants', 'departments', 'designations', 'shifts', 'festivals', 'charges',
            'employees', 'employee-view', 'attendance', 'advances', 'attendance-report',
            'salary-report', 'maintenance-report', 'roles', 'users',
        ];
        $actions = ['view', 'create', 'edit', 'delete'];

        $permissionIds = [];
        foreach ($modules as $module) {
            foreach ($actions as $action) {
                $permission = Permission::firstOrCreate(
                    ['module' => $module, 'action' => $action],
                    ['name' => "{$module}.{$action}"]
                );
                $permissionIds[] = $permission->id;
            }
        }

        $role->permissions()->syncWithoutDetaching($permissionIds);
        $role->plants()->sync(Plant::query()->pluck('id')->all());

        User::updateOrCreate(
            ['email' => 'superadmin@gmail.com'],
            [
                'name' => 'Super Admin',
                'username' => 'superadmin',
                'password' => Hash::make('Superadmin@123'),
                'role_id' => $role->id,
                'status' => 1
            ]
        );
    }
}
