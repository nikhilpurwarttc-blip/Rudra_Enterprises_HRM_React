# HRM API Documentation

Welcome to the HRM API Documentation. This document provides details on how to interact with the API, the required formats, and the expected responses.

## Base URL
All API requests should be prefixed with the `/api` route.
`http://localhost:8000/api`

## Common Headers
The frontend uses Laravel Sanctum stateful session cookies. First request the CSRF cookie, then send credentials with every API request:
```http
Accept: application/json
Content-Type: application/json
X-XSRF-TOKEN: {url-decoded XSRF-TOKEN cookie}
Cookie: laravel-session={session_cookie}; XSRF-TOKEN={csrf_cookie}
```

---

## Authentication

### 1. User Login
Authenticate a user and create a secure session cookie.

- **URL:** `/login`
- **Method:** `POST`
- **Auth Required:** No

#### Request Body (JSON)
| Field | Type | Required | Description | Validation |
|-------|------|----------|-------------|------------|
| `username` | string | Yes | The user's unique username | Max 255 chars |
| `password` | string | Yes | The user's password | Min 8 chars, max 255 chars |

**Example Request:**
```json
{
    "username": "superadmin",
    "password": "password123"
}
```

#### Responses

**Success Response (200 OK):**
```json
{
    "user": {
        "id": 1,
        "name": "Super Admin",
        "username": "superadmin",
        "email": "superadmin@example.com",
        "status": 1,
        "role": {
            "id": 1,
            "name": "Super Admin",
            "description": "Full access to the system"
        },
        "created_at": "2026-09-22T05:30:00.000000Z"
    }
}
```

**Validation Error (422 Unprocessable Entity):**
```json
{
    "message": "Username is required.",
    "errors": {
        "username": [
            "Username is required."
        ]
    }
}
```

**Invalid Credentials (401 Unauthorized):**
```json
{
    "message": "Invalid login credentials"
}
```

**Account Disabled (403 Forbidden):**
```json
{
    "message": "Your account is disabled."
}
```

---

### 2. User Logout
Logs out the authenticated user by invalidating their current session.

- **URL:** `/logout`
- **Method:** `POST`
- **Auth Required:** Yes (requires the Sanctum session cookie)

#### Responses

**Success Response (200 OK):**
```json
{
    "message": "Successfully logged out"
}
```

**Unauthenticated (401 Unauthorized):**
If the token is missing or invalid.
```json
{
    "message": "Unauthenticated."
}
```

---

## Roles Management

All Role endpoints require the `Authorization: Bearer {your_access_token}` header.

### 1. List Roles
- **URL:** `/roles`
- **Method:** `GET`
- **Response:** Returns an array of roles, including their attached permissions.

### 2. Create Role
- **URL:** `/roles`
- **Method:** `POST`
- **Request Body:**
```json
{
    "name": "HR",
    "description": "Human Resources",
    "status": 1,
    "permissions": [1, 2] // Optional: Array of permission IDs
}
```

### 3. Update Role
- **URL:** `/roles/{id}`
- **Method:** `PUT`
- **Request Body:** Same as Create Role. (Can optionally pass `permissions` to sync).

### 4. Delete Role
- **URL:** `/roles/{id}`
- **Method:** `DELETE`

### 5. Synchronize Route Permissions
- **URL:** `/permissions/seed`
- **Method:** `POST`
- **Request Body (JSON):** Optional array of frontend permission modules. Each module is created with `view`, `create`, `edit`, and `delete` actions if it does not already exist.
```json
{
    "modules": ["dashboard", "roles", "users"]
}
```

---

## Permissions Management

All Permission endpoints require the `Authorization: Bearer {your_access_token}` header.

### 1. List Permissions
- **URL:** `/permissions`
- **Method:** `GET`

### 2. Create Permission
- **URL:** `/permissions`
- **Method:** `POST`
- **Request Body:**
```json
{
    "name": "create_users",
    "module": "Users",
    "action": "create"
}
```

### 3. Update Permission
- **URL:** `/permissions/{id}`
- **Method:** `PUT`
- **Request Body:** Same as Create Permission.

### 4. Delete Permission
- **URL:** `/permissions/{id}`
- **Method:** `DELETE`

---

## Plants Management

All Plants endpoints require the `Authorization: Bearer {your_access_token}` header.

### 1. List Plants
- **URL:** `/plants`
- **Method:** `GET`
- **Response:** Returns an array of plants.

### 2. Create Plant
- **URL:** `/plants`
- **Method:** `POST`
- **Request Body:**
```json
{
    "plant_code": "PLT-001",
    "name": "Headquarters",
    "address": "123 Main St",
    "status": 1
}
```

### 3. Get Single Plant
- **URL:** `/plants/{id}`
- **Method:** `GET`
- **Response:** Returns a single plant.

### 4. Update Plant
- **URL:** `/plants/{id}`
- **Method:** `PUT`
- **Request Body:** Same as Create Plant.

### 5. Delete Plant
- **URL:** `/plants/{id}`
- **Method:** `DELETE`

---

## Shifts Management

All Shifts endpoints require the `Authorization: Bearer {your_access_token}` header.

### 1. List Shifts
- **URL:** `/shifts`
- **Method:** `GET`
- **Response:** Returns an array of shifts.

### 2. Create Shift
- **URL:** `/shifts`
- **Method:** `POST`
- **Request Body (JSON):**
```json
{
    "name": "Morning Shift",
    "start_time": "09:00",
    "end_time": "17:00",
    "duration_hours": 8,
    "status": 0
}
```

### 3. Get Single Shift
- **URL:** `/shifts/{id}`
- **Method:** `GET`
- **Response:** Returns a single shift.

### 4. Update Shift
- **URL:** `/shifts/{id}`
- **Method:** `PUT` / `PATCH`
- **Request Body:** Same as Create Shift (All fields are optional).

### 5. Delete Shift
- **URL:** `/shifts/{id}`
- **Method:** `DELETE`

#### Validation
- `name`: required string, maximum 255 characters
- `start_time`: required `H:i` time, for example `09:00`
- `end_time`: required `H:i` time, for example `17:00`
- `duration_hours`: optional numeric value
- `status`: optional boolean

---

## Holidays Management

All Holidays endpoints require the `Authorization: Bearer {your_access_token}` header.

### 1. List Holidays
- **URL:** `/holidays`
- **Method:** `GET`
- **Query Params:** `?plant_id={id}` or `?plant_id={id1},{id2}` (optional filter for single or multiple plants)
- **Response:** Returns an array of holidays.

### 2. Create Holiday
- **URL:** `/holidays`
- **Method:** `POST`
- **Request Body (JSON):**
```json
{
    "plant_id": [1, 2],
    "name": "Diwali",
    "holiday_date": "2026-11-08",
    "description": "Festival of lights",
    "status": 0
}
```

### 3. Get Single Holiday
- **URL:** `/holidays/{id}`
- **Method:** `GET`
- **Response:** Returns a single holiday.

### 4. Update Holiday
- **URL:** `/holidays/{id}`
- **Method:** `PUT` / `PATCH`
- **Request Body:** Same as Create Holiday (All fields are optional).

### 5. Delete Holiday
- **URL:** `/holidays/{id}`
- **Method:** `DELETE`

---

## Charges API

### 1. List Charges
- **URL:** `/charges`
- **Method:** `GET`
- **Response:** Returns a list of all charges.

### 2. Create Charge
- **URL:** `/charges`
- **Method:** `POST`
- **Request Body:**
  ```json
  {
      "deduction": "PF Deduction",
      "value_type": "percentage",
      "value": 12.5,
      "status": "active"
  }
  ```

### 3. Get Single Charge
- **URL:** `/charges/{id}`
- **Method:** `GET`
- **Response:** Returns a single charge.

### 4. Update Charge
- **URL:** `/charges/{id}`
- **Method:** `PUT` / `PATCH`
- **Request Body:** Same as Create Charge (All fields are optional).

### 5. Delete Charge
- **URL:** `/charges/{id}`
- **Method:** `DELETE`

---

## Departments API

### 1. List Departments
- **URL:** `/departments`
- **Method:** `GET`
- **Query Params:** `?plant_id={id}` (optional filter by plant)
- **Response:** Returns a list of all departments.

### 2. Create Department
- **URL:** `/departments`
- **Method:** `POST`
- **Request Body (JSON):**
```json
{
    "plant_id": 1,
    "department_code": "DPT-001",
    "name": "Human Resources",
    "status": 0
}
```

### 3. Get Single Department
- **URL:** `/departments/{id}`
- **Method:** `GET`
- **Response:** Returns a single department.

### 4. Update Department
- **URL:** `/departments/{id}`
- **Method:** `PUT` / `PATCH`
- **Request Body:** Same as Create Department (All fields are optional).

### 5. Delete Department
- **URL:** `/departments/{id}`
- **Method:** `DELETE`

---

## Designations API

### 1. List Designations
- **URL:** `/designations`
- **Method:** `GET`
- **Response:** Returns a paginated list of all designations.

### 2. Create Designation
- **URL:** `/designations`
- **Method:** `POST`
- **Request Body (JSON):**
```json
{
    "name": "Software Engineer",
    "description": "Develops and maintains software.",
    "status": 1
}
```

### 3. Get Single Designation
- **URL:** `/designations/{id}`
- **Method:** `GET`
- **Response:** Returns a single designation.

### 4. Update Designation
- **URL:** `/designations/{id}`
- **Method:** `PUT` / `PATCH`
- **Request Body:** Same as Create Designation (All fields are optional).

### 5. Delete Designation
- **URL:** `/designations/{id}`
- **Method:** `DELETE`

---

## Employees API

### 1. List Employees
- **URL:** `/employees`
- **Method:** `GET`
- **Response:** Returns a paginated list of all employees (15 per page). Includes eager loaded relations for `plant`, `department`, `designation`, `shift`, and `charges` to optimize speed and avoid N+1 queries.

### 2. Create Employee
- **URL:** `/employees`
- **Method:** `POST`
- **Content-Type:** `multipart/form-data` (if uploading image) or `application/json`
- **Request Parameters:**
  - `name`: string, required
  - `image`: file (jpeg, png, jpg, gif), optional (max 2MB)
  - Other optional fields: `dob`, `joining_date`, `plant_id`, `department_id`, `designation_id`, `status`, `mobile_number`, `address`, `gender`, `marital_status`, `shift_id`
  - `charge_ids[]`: array of integers, optional (e.g. `charge_ids[0]=1`)
- **Request Body Example (JSON, if not uploading image):**
```json
{
    "name": "John Doe",
    "dob": "1990-01-15",
    "joining_date": "2024-05-10",
    "plant_id": 1,
    "department_id": 2,
    "designation_id": 3,
    "status": 0,
    "mobile_number": "1234567890",
    "email": "john.doe@example.com",
    "address": "123 Main Street",
    "gender": "Male",
    "marital_status": "Single",
    "shift_id": 1,
    "charge_ids": [1, 2]
}
```
*(Note: If uploading an image, you must use `multipart/form-data` instead of JSON).*

### 3. Get Single Employee
- **URL:** `/employees/{id}`
- **Method:** `GET`
- **Response:** Returns a single employee with all relationships loaded.

### 4. Update Employee
- **URL:** `/employees/{id}`
- **Method:** `POST` (Use POST with `_method=PUT` parameter for `multipart/form-data` uploads, or standard `PUT`/`PATCH` for JSON without image)
- **Request Body:** Same fields as Create Employee. (All fields are optional, `charge_ids` array will sync the charges, removing any old ones not in the array. If `image` is uploaded, it will replace the old image).



### 5. Delete Employee
- **URL:** `/employees/{id}`
- **Method:** `DELETE`

---

## Employee Documents API

### 1. List Employee Documents
- **URL:** `/employee-documents`
- **Method:** `GET`
- **Response:** Returns a paginated list of all employee documents. Includes eager loaded relation for `employee`.

### 2. Create Employee Document
- **URL:** `/employee-documents`
- **Method:** `POST`
- **Content-Type:** `multipart/form-data` (if uploading document file) or `application/json`
- **Request Parameters:**
  - `employee_id`: integer, required
  - `document_type`: string, required
  - `document_number`: string, required
  - `document_file`: file (jpeg, png, jpg, gif, pdf), optional (max 5MB)
  - `status`: integer, optional (1=active, 0=inactive)
- **Request Body Example (JSON, if not uploading file):**
```json
{
    "employee_id": 1,
    "document_type": "Aadhar Card",
    "document_number": "1234-5678-9012",
    "status": 1
}
```

### 3. Get Single Employee Document
- **URL:** `/employee-documents/{id}`
- **Method:** `GET`
- **Response:** Returns a single employee document.

### 4. Update Employee Document
- **URL:** `/employee-documents/{id}`
- **Method:** `POST` (Use POST with `_method=PUT` parameter for `multipart/form-data` file uploads, or standard `PUT`/`PATCH` for JSON without file)
- **Request Body:** Same fields as Create Employee Document (All fields are optional. If `document_file` is uploaded, it will replace the old file).

### 5. Delete Employee Document
- **URL:** `/employee-documents/{id}`
- **Method:** `DELETE`

---

## Guidelines for Development
- All endpoints must return `JSON`. Make sure to set the `Accept: application/json` header.
- Status codes are strictly followed (200 for success, 401 for unauthorized, 422 for validation, etc.).
- Validation messages are customized per the `LoginRequest`.


---

## Employee Bank Accounts API

All endpoints require the Bearer token in the Authorization header.

### 1. List Employee Bank Accounts
- **URL:** /employee-bank-accounts
- **Method:** GET
- **Response:** Returns a paginated list of all employee bank accounts.

### 2. Create Employee Bank Account
- **URL:** /employee-bank-accounts
- **Method:** POST
- **Request Parameters:**
  - \employee_id\: integer, required
  - \ank_name\: string, required
  - \ccount_number\: string, required
  - \ifsc_code\: string, optional
  - \ccount_holder_name\: string, required
  - \is_primary\: boolean/integer, optional
  - \status\: integer, optional (1=active, 0=inactive)
- **Request Body Example:**
\\\json
{
    "employee_id": 1,
    "bank_name": "State Bank of India",
    "account_number": "123456789012",
    "ifsc_code": "SBIN0001234",
    "account_holder_name": "John Doe",
    "is_primary": 1,
    "status": 1
}
\\\

### 3. Get Single Employee Bank Account
- **URL:** /employee-bank-accounts/{id}
- **Method:** GET
- **Response:** Returns a single employee bank account.

### 4. Update Employee Bank Account
- **URL:** /employee-bank-accounts/{id}
- **Method:** PUT / PATCH
- **Request Body:** Same fields as Create Employee Bank Account (All fields are optional).

### 5. Delete Employee Bank Account
- **URL:** /employee-bank-accounts/{id}
- **Method:** DELETE

---

## Users API

### 1. List Users
- **URL:** `/users`
- **Method:** `GET`
- **Response:** Returns a paginated list of all users. Includes `role` and `employee`.

### 2. Create User
- **URL:** `/users`
- **Method:** `POST`
- **Request Parameters:**
  - `name`: string, required
  - `username`: string, required
  - `email`: string, optional
  - `password`: string, required (min 8)
  - `role_id`: integer, required
  - `employee_id`: integer, optional (Use this from frontend Employee dropdown)
  - `status`: boolean/integer, required

### 3. Get Single User
- **URL:** `/users/{id}`
- **Method:** `GET`
- **Response:** Returns a single user with relations.

### 4. Update User
- **URL:** `/users/{id}`
- **Method:** `PUT` / `PATCH`
- **Request Body:** Same fields as Create User (All fields are optional except you should pass `password` only if changing it).

### 5. Delete User
- **URL:** `/users/{id}`
- **Method:** `DELETE`

---

## Employee Advances API

All Employee Advance endpoints require the `Authorization: Bearer {your_access_token}` header.

### 1. List Employee Advances
- **URL:** `/employee-advances`
- **Method:** `GET`
- **Query Params:**
  - `employee_id`: filter by employee
  - `payment_mode`: filter by payment mode (1=Cash, 2=Bank)
  - `status`: filter by status (1=Pending, 2=Recovered, 3=Cancelled)
  - `start_date` / `end_date`: filter by date range
- **Response:** Returns a paginated list of advances.

### 2. Create Employee Advance
- **URL:** `/employee-advances`
- **Method:** `POST`
- **Request Parameters:**
  - `employee_id`: integer, required
  - `advance_date`: date, required
  - `amount`: numeric (> 0), required
  - `payment_mode`: integer (1=Cash, 2=Bank), required
  - `purpose`: string, optional
  - `remarks`: string, optional
- **Request Body Example:**
```json
{
    "employee_id": 1,
    "advance_date": "2026-09-28",
    "amount": 10000,
    "payment_mode": 1,
    "purpose": "Salary Advance",
    "remarks": "September advance"
}
```
*Note: `settlement_date` will automatically be set to the last day of the `advance_date`'s month.*

### 3. Get Single Employee Advance
- **URL:** `/employee-advances/{id}`
- **Method:** `GET`

### 4. Update Employee Advance (Basic Fields)
- **URL:** `/employee-advances/{id}`
- **Method:** `PUT` / `PATCH`
- **Request Body:** Same fields as Create, but all are optional. *Note: `recovered_amount`, `remaining_amount`, `status`, and `settlement_date` cannot be edited here.*

### 5. Recover Employee Advance
- **URL:** `/employee-advances/{id}/recover`
- **Method:** `POST`
- **Request Parameters:**
  - `recovery_amount`: numeric, required
- **Request Body Example:**
```json
{
    "recovery_amount": 2000
}
```
*Note: The recovery must happen in the exact same month the advance was taken. The system automatically calculates the new remaining amount and updates the status to Recovered if fully paid.*

### 6. Cancel Employee Advance
- **URL:** `/employee-advances/{id}/cancel`
- **Method:** `POST`
- **Response:** Cancels the advance (only if no recoveries have been made).

### 7. List Advances for a Specific Employee
- **URL:** `/employees/{id}/advances`
- **Method:** `GET`
- **Response:** Returns a paginated list of advances belonging to the specified employee.
