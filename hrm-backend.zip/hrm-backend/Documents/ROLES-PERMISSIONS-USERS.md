# Roles, Permissions, Users और Plant Access

## संक्षिप्त उत्तर

`view`, `create`, `edit`, और `delete` permissions तथा plant access एक ही mechanism से map नहीं हैं।

### Route/action permissions

Frontend में route permissions के लिए:

- `src/hooks/usePermission.js`
- `src/constants/routes.js`
- `src/App.jsx`
- `src/layout/Sidebar.jsx`

Backend में:

- `app/Http/Middleware/EnsureApiPermission.php`
- `User::hasPermission($module, $action)`

उदाहरण: किसी user को `employees.view` permission नहीं है, तो frontend route block होगा और backend API भी `403` देगा।

### Plant permissions

Plant access role के साथ assigned plants से आता है:

- `roles` और `plants` के बीच `plant_role` pivot table
- `Role::plants()` relationship
- `User::accessiblePlantIds()`
- `User::canAccessPlant($plantId)`

Plant permission `usePermission.js` में action की तरह नहीं है। यह backend data scope है। इसलिए plant access को केवल frontend में hide करना पर्याप्त नहीं है। Backend queries और mutations भी scoped हैं।

## पूरा किया गया काम

### Roles और Permissions

- Role create, update, delete और list UI मौजूद है।
- Role permission matrix में modules और actions दिखते हैं।
- प्रत्येक route/module के लिए `view`, `create`, `edit`, `delete` actions manage किए जा सकते हैं।
- Permission matrix की mapping `ROUTE_PERMISSIONS` और `PERMISSION_GROUPS` से होती है।
- Backend `EnsureApiPermission` HTTP method के आधार पर action तय करता है:
  - `GET` / `HEAD` -> `view`
  - `POST` -> `create`
  - `PUT` / `PATCH` -> `edit`
  - `DELETE` -> `delete`
- Super Admin backend permission check को bypass करता है।
- नए `designations` module की permissions permission seeder में जोड़ी गई हैं।

### Role-to-Plant Access

- Role editor में multiple plants select करने की सुविधा है।
- Role payload में `plant_ids` भेजे जाते हैं।
- Backend `plant_ids` validate करता है और `role->plants()->sync(...)` करता है।
- `plant_role` pivot migration create हो चुकी है।
- Role response में `plant_ids` और `plants` उपलब्ध हैं।
- Generated Super Admin role को seeder में सभी existing plants assign किए जाते हैं।
- Super Admin के लिए `accessiblePlantIds()` `null` लौटाता है, जिसका अर्थ है सभी plants की access।

### Users

- User को employee के साथ link करने के लिए employee dropdown है।
- Dropdown में employee name, employee ID और designation दिखती है।
- Employee select करने पर auto-fill होता है:
  - Full name
  - Username
  - Default password: `FirstName@123`
  - Email, यदि employee response में email उपलब्ध हो
- Role user द्वारा manually select किया जाता है।
- Email optional है। Backend database migration से `users.email` nullable है।
- Password field में eye/eye-off visibility toggle है।
- Client-side और Laravel validation errors:
  - Inline red error box में दिखाई देते हैं।
  - Toast में field name के साथ readable message दिखाई देता है।
- Generated `superadmin` user Users page में hide है।
- Generated `Super Admin` role Roles page में hide है।
- Normal admin users और roles hide नहीं किए गए हैं।

### Plant-scoped backend access

Non-Super Admin users के लिए backend अब इन resources को assigned plants तक सीमित करता है:

- Plants
- Employees
- Departments
- Holidays
- Users linked to employees
- Employee documents
- Employee bank accounts
- Roles और role plant assignments

Detail, create, update और delete requests में भी plant ownership/access check होता है। केवल frontend filtering पर निर्भर नहीं किया गया है।

## Current access flow

1. User login करता है।
2. Authenticated profile में role permissions और role plant IDs load होते हैं।
3. Frontend `usePermission()` route/action buttons और pages को नियंत्रित करता है।
4. Backend `EnsureApiPermission` route action permission enforce करता है।
5. Backend `accessiblePlantIds()` user के allowed plant IDs निकालता है।
6. Resource controllers list को filter करते हैं और cross-plant detail/mutation पर `403` देते हैं।

## Pending / ध्यान देने योग्य बातें

### Attendance API अभी pending है

Frontend में attendance page और employee attendance routes मौजूद हैं, लेकिन backend में अभी:

- Attendance model नहीं है।
- Attendance migration नहीं है।
- Attendance controller/API नहीं है।
- Attendance records save करने का endpoint नहीं है।

इसलिए plant-based employee visibility लागू है, लेकिन actual attendance marking और attendance reports में plant authorization तभी enforce होगी जब attendance backend API बनाया जाएगा। उस API में employee के plant को `canAccessPlant()` से verify करना जरूरी होगा।

### Frontend plant data filtering

Backend सही scope enforce करता है। Frontend को भी केवल allowed plants मिलते हैं क्योंकि `/plants` endpoint scoped है। फिर भी भविष्य में shared plant selector या cached data जोड़ते समय backend authorization को replace नहीं करना चाहिए।

### Existing users without employee link

Non-Super Admin user जिसका `employee_id` null है, `/users` list में plant-scoped user listing में दिखाई नहीं देगा। ऐसे users के लिए policy तय करनी होगी:

- उन्हें केवल Super Admin manage करे; या
- उन्हें किसी employee/plant से link करना अनिवार्य हो।

### Role with no assigned plants

Non-Super Admin role जिसमें कोई plant assigned नहीं है, उसे कोई plant-owned record access नहीं मिलेगा। यह current design के अनुसार intentional है।

### Automated test coverage

Current backend test suite में केवल basic example tests हैं। Plant authorization के लिए dedicated feature tests अभी pending हैं, विशेष रूप से:

- Plant 1 user Plant 2 employee नहीं देख सकता।
- Plant 1 user Plant 2 employee update/delete नहीं कर सकता।
- Multi-plant supervisor दोनों assigned plants देख सकता है।
- Super Admin सभी plants देख सकता है।
- Role plant assignment unauthorized plant को reject करता है।

## मुख्य files

### Frontend

- `hrm-frontend/src/hooks/usePermission.js`
- `hrm-frontend/src/constants/routes.js`
- `hrm-frontend/src/pages/Users/Roles.jsx`
- `hrm-frontend/src/pages/Users/Users.jsx`
- `hrm-frontend/src/store/api.js`

### Backend

- `hrm-backend/app/Http/Middleware/EnsureApiPermission.php`
- `hrm-backend/app/Models/User.php`
- `hrm-backend/app/Models/Role.php`
- `hrm-backend/app/Models/Plant.php`
- `hrm-backend/app/Http/Controllers/Api/RoleController.php`
- `hrm-backend/app/Http/Controllers/Api/EmployeeController.php`
- `hrm-backend/database/migrations/2026_09_25_120000_create_plant_role_table.php`
- `hrm-backend/database/seeders/SuperAdminSeeder.php`
